# TYOS
0.5.6</br>
A mobile operating system for the TyTelli.

copyright :copyright: 2015 Tyler Spadgenske

##Installation and Setup
Follow the guide at:</br>
http://instructables.com/id/Build-Your-Own-Smartphone/</br>

##Docs
Check out the docs at https://github.com/spadgenske/tyos/wiki

##Update
To update your version of TYOS do so here: </br>
https://github.com/spadgenske/TYOS/releases
