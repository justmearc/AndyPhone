#Credits
Programmed by Tyler Spadgenske

Some icons and images are based off ones from the Noun Project (https://thenounproject.com)</br> 
These icons were drawn by:</br>
1. Jason Grube</br>
2. Scott Lewis</br>
3. Simple Icons</br>
4. Jardson Almeida</br>
5. Marek Polakovic</br>
6. icons.design</br>
7. Michael Zenaty</br>
8. Alexander Smith</br>
9. Rodolfo Alvarez</br>

Project Inspired by Dave Hunt's PiPhone and Adafruit's Cam Pi project.
